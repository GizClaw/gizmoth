# @gizclaw/models-player

Interactive models for H106 Tiga/Zero/Orb/Zeta and independent Pi Tin.
Version 0.6.0 connects Orb/Zeta's LCD, backlight, core LEDs and model/keyboard
buttons to provider-selected Web firmware through `createModelPlay`. Their
independent Trial firmware choices come from the published Models Provider;
the viewer never infers a compatible firmware from geometry or another product.
Version 0.5.0 adds authored CMF appearances for Orb and Zeta, including original
artwork textures, independent keys, service covers and each character's call/timer
recordings. Load `h106-orb` or `h106-zeta` with `loadModelPlayer`, then use the
same `createH106Viewer` and `appearance` APIs. Their `h106-cmf-v1` assets are a
GLB, integrity-bound interaction JSON and two Ogg files in one version directory.
The finished models omit the top hooks; original CAD remains with Deploy.
`hasServiceCover`, `coverOpen` and `setCoverOpen(open)` expose H106 cover control.
The sound-only API also accepts these identities without loading geometry.
Orb/Zeta preview remains independent of firmware availability. With an admitted
runtime, the existing `ModelPlay.display` API also exposes its live framebuffer;
the dedicated touch Play View remains a separate capability.

Version 0.4.0 adds
JSON shortcuts, built-in configuration help and the H106 Trial WASM command bridge.
Version 0.3.0 adds
shared responsive Play Views, radio presets and secure GizClaw transport.
Version 0.2.0 adds
public live firmware display access and model-only rendering suspension for
host-owned screen-only views. Version 0.1.10
restores a light gray inner emitting surface beneath the H106 optical cover
when the LED is off, preserving the reviewed blue/red lit appearance.
Version 0.1.9 adds provider-selected Web firmware Play. Version 0.1.8 adds
the narrated H106 SIM guide. Version 0.1.7 added
appearance-specific H106 ready/timer recordings and their measured light rhythms.
It retains the relative view rotation introduced in 0.1.6 and the fitted
framing, transparent bloom, H106 optical/audio timing and spatial keyboard
controls from 0.1.5 and the energy-core/appearance APIs introduced in 0.1.4.
The original `@gizclaw/h106-viewer` package and its published versions are retained.

## Model icons

Version 0.7.0 adds `getModelIcon` for every `PlayerModelId`, including FunKey S.
Import from the lightweight root or `@gizclaw/models-player/icons`; neither
lookup loads a viewer, Three.js, model geometry, firmware or network resources.
The returned SVG data URL works offline in `img.src` and CSS `mask-image`,
including dependency-optimized builds. The six transparent monochrome glyphs
use a 48 × 48 viewBox and are designed for 24 px display.

```js
import { getModelIcon } from '@gizclaw/models-player/icons'

image.src = getModelIcon('h106-orb')
image.alt = 'H106 Orb'
image.width = image.height = 24

// A mask takes its color from the host element.
icon.style.backgroundColor = 'currentColor'
icon.style.mask = `url("${getModelIcon('pi-tin')}") center / contain no-repeat`
icon.style.width = icon.style.height = '24px'
```

`getModelIcon(model: PlayerModelId): string` always returns an icon. The string
overload returns `string | undefined` for external IDs; unknown IDs have no
fallback. Raw assets are exported as
`@gizclaw/models-player/icons/h106-orb.svg` (and the other five model IDs).
Label meaningful images; mark decorative icons as hidden from assistive tools.
These source-owned glyphs simplify the physical front silhouettes: Tiga's
pointed oval, Zero's angular shield, Orb's round body and tapered grip, Zeta's
broad shield, Pi Tin's wide clamshell and FunKey S's compact clamshell.
H106 references are the published models and the existing Tiga/Zero product
images; handheld references are the projects linked by `thirdPartyHandhelds`.

## Hidden JSON shortcuts

Focus the player and press **Ctrl/Cmd + Shift + K** to open the shortcut editor.
Press **Ctrl/Cmd + Shift + H** to read the built-in configuration guide, including
field definitions, physical key syntax, a copyable full JSON example and
workspace/workflow instructions. The editor also has a **Configuration help**
button. Help works before firmware startup. Returning from help preserves an
unsaved draft; Escape closes only the current panel and restores focus.
It works in inline Forge, fullscreen Play and the Model/Screen Play Views.
Save applies validated JSON and remembers it in this browser, separately for
each model. Invalid JSON leaves the active bindings unchanged. Defaults are
**Alt + Shift + M** to mute and **Alt + Shift + U** to unmute.

The enabled H106 live-demo examples use **Alt + Shift + 1–6**:

| Key | Example | Command target |
| --- | --- | --- |
| 1 | Adventure · Space rescue | `h106-adventure.space-rescue`, kickoff |
| 2 | Little theater · Journey to the West | `h106-journey`, kickoff |
| 3 | Guess the animal | `h106-guess.animals`, kickoff |
| 4 | Lua App · CatNest | `lua.app.run`, `app_id: catnest` |
| 5 | General chat | `h106-chat` |
| 6 | Chinese-English translation | `h106-translate-zh-en-auto` |

Start H106 Trial and wait for its connection before using the workflow examples.
Saved custom configurations remain unchanged; choose **Load example**, then
**Save and apply** to replace an older configuration with these defaults.

```json
{
  "version": 1,
  "shortcuts": [
    {
      "keys": "Alt+Shift+KeyM",
      "command": {"method": "mhs.write", "id": "speaker.main", "hwd": "speaker", "payload": {"muted": true}}
    },
    {
      "keys": "Alt+Shift+KeyU",
      "command": {"method": "mhs.write", "id": "speaker.main", "hwd": "speaker", "payload": {"muted": false}}
    },
    {
      "keys": "Alt+Shift+Digit1",
      "command": {"method": "tools.invoke", "tool": "run.workspace.set", "args": {"workspace_name": "h106-adventure.space-rescue", "kickoff": true}}
    },
    {
      "keys": "Alt+Shift+Digit2",
      "command": {"method": "tools.invoke", "tool": "run.workspace.set", "args": {"workspace_name": "h106-journey", "kickoff": true}}
    },
    {
      "keys": "Alt+Shift+Digit3",
      "command": {"method": "tools.invoke", "tool": "run.workspace.set", "args": {"workspace_name": "h106-guess.animals", "kickoff": true}}
    },
    {
      "keys": "Alt+Shift+Digit4",
      "command": {"method": "tools.invoke", "tool": "lua.app.run", "args": {"app_id": "catnest"}}
    },
    {
      "keys": "Alt+Shift+Digit5",
      "command": {"method": "tools.invoke", "tool": "run.workspace.set", "args": {"workspace_name": "h106-chat", "kickoff": false}}
    },
    {
      "keys": "Alt+Shift+Digit6",
      "command": {"method": "tools.invoke", "tool": "run.workspace.set", "args": {"workspace_name": "h106-translate-zh-en-auto", "kickoff": false}}
    }
  ]
}
```

Use `h106-<workflow-name>` for a workflow available in the current H106 catalog
when customizing these examples. On execution, firmware looks up the workspace;
if it is missing, the session attempts to create it from that workflow, reads
it back, and activates it. Manual workspace creation is not required. Saving
the shortcut JSON alone creates nothing. H106 selects the workspace and its associated workflow;
the current firmware API has no independent
`workflow.set` tool. Tool success means the firmware accepted the request; the
device owns completion of asynchronous workspace activation. The editor's **List firmware tools** action lists the actual
running firmware's tools. Commands support `tools.list`, `tools.invoke`,
`mhs.read` and `mhs.write`, with the official `@gizclaw/firmware` codec and errors.
Muted writes preserve the firmware's stored volume, including an intentional 0%.
`lua.app.run` requires an installed app and an idle Home screen; H106 Trial
preinstalls `catnest`. `lua.app.list` returns available app IDs. Hold Back (E/U)
for about two seconds to leave the app before using workflow commands again.
Teams navigation has no current invoke tool and is not part of these examples.

`keys` uses physical `KeyboardEvent.code` names with optional `Ctrl`, `Meta`,
`Alt`, `Shift`, or `Mod` (Ctrl or Meta). Modifier matching is exact. Duplicate
bindings and the editor/help chords are rejected. Typing in editable fields, IME
composition and key repeat do not execute commands. Only the focused player's
scope receives shortcuts; one command runs at a time and failures are visible.

Hosts may pass `shortcuts` to `createModelPlay`/`createModelPlayView`, or use
`player.setShortcuts(config)`, `player.openShortcutSettings()`, `player.openShortcutHelp()` and
`player.executeCommand(command, {signal?, timeout_ms?})`. Programmatic setters
change the session; the editor's Save action persists it. `shortcuts: false`
disables keyboard bindings, the editor and help. For custom screen controls,
`player.bindShortcuts(element)` extends the focus scope and returns cleanup.

The default runtime binds the existing WASM `Module.h2GizClaw` after firmware
startup. It never creates another device connection. Stop, replacement and
destroy close only this SDK client's pending calls. Legacy custom runtimes may
omit `executeCommand`; their ordinary controls remain usable. The new H106
Trial PAL Web shell (`h2WebConfigureEnvironment`, queued button input and
`H2_WEB_APP` lifecycle markers) and legacy app_host are both supported.

## H106 rendering performance in 0.3.2

Stationary H106 scenes stop their own animation-frame scheduling and GPU draws.
Orbit damping, held keys, mechanical strokes, cover movement, energy pulses,
SIM guidance and running firmware keep the necessary frames active. Appearance,
resize, input and lifecycle changes wake the scene. Explicit
`setRenderingEnabled(false)` still takes precedence and never pauses firmware
or audio. Review adapters retain continuous rendering for their custom edits.

Production H106 shadow maps are reused while only the camera, LCD or LED color
changes. Moving parts, SIM guidance and material/lighting changes refresh them.
The existing geometry, pixel ratio, shadows, transmission and bloom remain.
Touch/drag input skips hover-only CAD raycasts.

Production H106 scenes also share converted materials from the same original
material and combine static opaque meshes only when their exact transforms,
vertex formats and rendering rules match. Every original vertex and triangle
remains; original named meshes still own picking. Moving buttons, the optical
assembly, covers, alpha surfaces and dynamic buffers stay independent. Changed
transforms, visibility, geometry, layers or material mode fall back to individual
meshes before drawing. Review scenes keep the original editable structure.

The LCD's final brightness overlay builds its occlusion depth with lightweight
depth materials instead of rerunning physical lighting and transmission. Alpha,
clipping, depth/stencil behavior and line markings are retained; color-disabled
surfaces that write neither depth nor stencil are omitted from that pass only.
The original GLBs, model resolution, camera, lighting and optical settings stay
unchanged. This does not reduce model download size.

`SDK_GEOMETRY_BASELINE=/path/to/built/package make test-browser-models-player-geometry`
compares both models at 720x960 across views, light/dark backgrounds, finishes,
pressed buttons, optical inspection, open covers and SIM guidance. The test-only
observer reads the real production scene. It checks unchanged source triangle
counts, fewer draws, image RMS error at most 0.5 of 255, and at most 0.01% isolated
high-contrast edge pixels differing by more than two levels. Captures and full
metrics go to ignored `build/models-player/geometry/`; `MODEL_GEOMETRY_OUTPUT`
overrides that path. Material reuse/batching can change edge rounding, so these
captures are visually compared rather than claimed byte-identical.

A decorative `H106Simulator` may declare `animated: false` for a static canvas.
After changing that artwork, call `viewer.requestRender()`; firmware adapters
retain the animated default. Play start/stop/install wakes its existing renderer.

`make test-browser-models-player-performance` counts real WebGL submissions and
owned RAF callbacks for both reviewed models at 720x960. It checks idle, rotation,
energy, keyboard, suspension and teardown, and writes captures/results below
ignored `build/models-player/performance/`. `MODEL_PERFORMANCE_OUTPUT` changes
that output directory. `SDK_PACKAGE_DIR` selects an installed package for
comparison; `MODEL_PERFORMANCE_BASELINE=1` records its continuous-render baseline.
These are browser software measurements, separate from physical-phone FPS.

## Container Play Views in 0.3.0

The optional `@gizclaw/models-player/play-view` entry owns the complete desktop,
tablet and phone Play presentation. This additive API retains 0.2.0 display/rendering controls. Existing `createModelPlay` and Forge inline clients
retain their contracts.

```ts
import { createModelPlayView } from '@gizclaw/models-player/play-view'
import '@gizclaw/models-player/style.css'
import '@gizclaw/models-player/play-view.css'

// The host gives this element an explicit width and height.
const view = createModelPlayView(container, {
  model: 'h106-tiga',
  layout: 'auto', // 'tablet' or 'phone' may be selected explicitly.
  language: 'zh-CN',
  onClose: () => closeHostRoute(),
})
await view.ready // Installs, but does not start WASM/audio.
view.setView('screen') // Same firmware, audio, camera and input instance.
view.setView('model')
// Native safe areas, in CSS pixels: top, right, bottom, left.
view.setHostLayout({ safeArea: [24, 0, 20, 0], textScale: 1 })
view.suspend() // Background: release input and stop the firmware/audio.
await view.restart() // Explicit restart; retains selected Model/Screen mode.
await view.shutdown() // Normal route close; waits for Stop without invoking onClose.
view.destroy() // Forced cleanup/unmount. Terminal and idempotent.
```

For a webpage-filling view, the same entry also exports `openModelPlayView`:

```ts
import { openModelPlayView } from '@gizclaw/models-player/play-view'

const play = openModelPlayView({
  model: 'h106-tiga',
  layout: 'responsive', // Default for the webpage dialog.
  // Optional: borrow an existing inline preview and its original container.
  session: { player: existingInlinePlay, container: previewContainer },
})
await play.ready
await play.close() // Stop firmware, restore the preview, body scroll and focus.
```

`openModelPlayView` owns a native HTML dialog covering the webpage, without
requesting browser fullscreen. It defaults to `responsive`, keyboard hints and
the firmware menu. `createModelPlayView(container, options)` continues to leave
presentation to the host and defaults to touch-only `auto`, preserving native
consumers. A borrowed `session` must be an inline `createModelPlay` for the same
model, mounted in the supplied original container. The view temporarily moves
that container and subscribes through `ModelPlay.subscribe`; it creates no second
renderer, firmware or audio owner. On teardown it exits Play and restores the
container and its styles, without destroying the host-owned preview. `subscribe`
immediately reports the current state and returns an unsubscribe function.

`responsive` selects desktop when the usable container is at least 1200px wide
and the primary pointer is fine. Otherwise both dimensions >=600px select tablet;
smaller containers select phone. `desktop`, `tablet` and `phone` can also be forced.
A ResizeObserver and pointer capability changes update the current instance.
Desktop shows keyboard hints with no virtual keys. `keyboardHints` is enabled by
default for responsive/desktop views and all webpage dialogs: the panel starts
expanded at >=1200x650, otherwise a keyboard button opens the collapsed panel.
State/frame updates preserve the user's expanded/collapsed choice. All layouts use
one dark palette, including menus, keyboard hints, keycaps and selected tabs;
resizing changes the layout without changing the theme. Short portrait phone
containers (<640px high) use a compact single-row toolbar and a 172px view switch.
The product remains identified by the region label; with the web menu enabled,
Reinstall stays in that menu. This gives a 184px LCD at 320x568. Popover size and
scrolling are constrained by the supplied container rather than the outer page. `firmwareMenu`
adds a styled picker for multiple admitted firmwares, a readout for one, Reinstall
and Power off. Escape closes the picker before the menu. No native select or
application UI framework is required. Initial installation and every explicit
reinstall remain distinct from a user-initiated Power press.

The SDK owns generic simulated-radio presets. `createModelPlay`,
`createModelPlayView` and `openModelPlayView` default to dual Wi-Fi/cellular
radios; no Forge configuration or extra client environment fields are required.
`environment` accepts `'both'`, `'wifi'`, `'modem'`, `'offline'` or a validated
`WebFirmwareEnvironment` object. `createModelPlayEnvironment(preset)` returns a
fresh structured preset for lower-level integrations. Presets enable connected
Wi-Fi and/or a registered cellular radio with a simulated SIM; offline disables
both radios and their connected/registered states. Identity/signal fields stay
SDK-owned unless the client supplies an explicit object.

```ts
const view = createModelPlayView(container, { model: 'h106-tiga' }) // Both radios.
view.setEnvironment('offline') // Same firmware/audio instance.
view.setEnvironment('wifi')
await view.restart() // Retains Wi-Fi selection.
```

`ModelPlay.environment` is a fresh snapshot. Both controller and view expose
`setEnvironment` with the same preset/object input. A borrowed view preserves
its controller's existing custom environment unless the view supplies an explicit
override. `ModelPlayViewState.network` reports the radio mode. With
`firmwareMenu: true`, the shared dark menu exposes all four presets on desktop,
tablet and phone; LiteLink's native wrapper enables this menu as well. Changing
mode applies through the existing app_host injection API without creating another
runtime. Initialization injects before Start. Reinstall, layout/view changes and
suspension/restart retain the selection within the view. A rejected UI update
keeps the previous mode, stops the firmware and shows Retry instead of claiming
that the new mode took effect.

These defaults are SDK policy for model Play. The lower-level Web firmware adapter
and GizOS Web PAL remain independent, and raw custom environments stay supported.
Actual Fetch/WebRTC traffic still uses the browser and the firmware's configured
service; simulated radio availability does not itself establish service readiness.

Older admitted firmware uses `http://ap.dev.gizclaw.com:9821` or
`http://ap.gizclaw.com:9821`. Before Start, the SDK installs an iframe-scoped Fetch
adapter that upgrades only those canonical hosts' HTTP default/9821 listeners to
the same host's HTTPS gateway on port 443. Path, query, request body, headers,
signal and caller options are preserved; HTTPS and custom endpoints pass through.
Teardown restores the adapter without changing parent-page Fetch or verified
firmware bytes. This does not select a different backend environment.

Hosts must allow `https://ap.dev.gizclaw.com` and `https://ap.gizclaw.com` in the
Play document's CSP `connect-src`, alongside firmware delivery origins. Keep
native cleartext restrictions and certificate validation enabled. Radio simulation
cannot bypass CSP, CORS or a service outage; the firmware's own connection status
remains authoritative.

`loadModelPlayView()` is the lazy root entry. Importing/selecting the module is
SSR-safe and starts no renderer, network request, firmware or audio. Mount it
when the user opens Play. The admitted touch controls currently cover H106
Tiga/Zero; other renderer families retain their existing independent APIs.

`tablet` uses two mirrored thumb arcs: 180px radius, 40-degree slots, equal 80px
circular halo keys, 64px side grip margins and 48px safe-bottom clearance.
`phone` retains the 64px controls, central Light core and lower Power control,
with a compact landscape layout. `auto` observes the container, selecting tablet
when both usable dimensions are at least 600px. Narrow tablet windows use compact
keys when the two arcs cannot fit; landscape widths below 1080px also compact
the controls to retain a readable LCD. Landscape gutters follow the actual
inner key edges with a 12px screen gap. At 900x600 the LCD is 420px square,
and at 1080x600 it stays 364px square. Model canvas size and model zoom are separate;
the tablet canvas fills its area while the model shares the flat LCD's center.
The LCD ratio comes from model geometry (240x240 for both H106 models), including
preboot/reinstall. It never inherits a temporary framebuffer's dimensions.

The package owns header, one sliding Model/Screen selection, status, loading
poster, model/display rendering, key positions, pointer/keyboard input and core
paint. Per-pointer input sources retain simultaneous holds and release on cancel,
blur, resize, suspension and teardown. No cards intercept the spaces between keys.
`onHaptic` lets a native shell retain selection haptics. `onStateChange` reports
phase/view/layout/error, with diagnostic details kept out of the user-facing UI.
`poster` is optional. `--model-play-font` inherits a host font without bundling
application fonts into the SDK. Reduced motion is supported through media query
and `setHostLayout({reducedMotion: true})`. Without explicit host insets,
CSS safe-area values are read on resize for browsers with viewport-fit cover.

The same installed `ModelPlay` owns runtime and audio in both views. New
`ModelPlay.outputs` exposes a fresh read-only PAL color/backlight snapshot;
consumers do not inspect firmware iframe internals. The package's Web firmware
adapter probes WebKit RGBA copy support and scopes the compatibility conversion
to its owned iframe, restoring it on teardown. No firmware bytes are rewritten.

Native fullscreen routing, OS orientation/system-bar restoration, loopback asset
serving and origin isolation remain host responsibilities. `onClose` never
assumes a browser fullscreen operation. The same secure-origin/COOP/COEP/CSP and
provider admission rules as bare Play still apply. Hardware/deployment acceptance
remains independent of npm/source and simulator validation.

Validate the package with `npm ci && npm test`. `tests/play-view.test.mjs` covers
layout geometry, simultaneous and external input, resize cancellation, stale
readiness, borrowed preview restoration/retry, keyboard hints, firmware selection,
host callback failure, retained sessions, unsupported capability and cleanup; the lazy test includes
the new entry. `tests/play-display.test.mjs` covers framebuffer copying,
backlight, ratio, replacement and visibility. Web consumers additionally check
webpage-dialog dismissal, focus restoration and responsive sizes with real
firmware. Native consumer validation must additionally exercise the real
WebView, two device layouts and actual firmware playback.

Local consumer validation on 2026-10-11 used LiteLink's `file:` dependency on
this package. iPadOS 26.2 and iOS 26.5 native WebViews passed real firmware
video/audio decoding, same-session Model/Screen switching, paired key input,
3D suspension/resume and native route dismissal. Before/after simulator captures
retained identical colored-model bounds in iPad and iPhone portrait. These are
local source/simulator results, not an npm publication or physical-device claim.

## Install

Keep the default npm registry and configure the GizClaw scope in `.npmrc`:

```ini
@gizclaw:registry=https://static-volc.gizclaw.com/npm
```

```sh
npm install @gizclaw/models-player@0.4.0
```

0.1.9 adds Play alongside the retained 0.1.8 SIM guide. Firmware archives and
compatibility metadata are delivered independently of the npm package.

## Load on demand

The default entry imports no Three.js or renderer and downloads no model or
firmware. Select a renderer only on the user's open/load action:

```ts
import { loadModelPlayer } from '@gizclaw/models-player'
import '@gizclaw/models-player/style.css'

const { createH106Viewer } = await loadModelPlayer('h106-tiga')
const viewer = createH106Viewer(container, { model: 'h106-tiga' })
await viewer.ready
const unsubscribe = viewer.buttons.subscribe(({ button, pressed }) => {
  // Connect application behavior here.
})
// On close/unmount:
unsubscribe()
viewer.destroy()
```

`h106-zero` selects Zero. Each H106 model fetches only its own
`models/h106/<product>/manifest.json` and its integrity-bound GLB and line JSON.
Optional `{product, assets}` explicit descriptors remain supported, as do
language, zoom, button events, reset, simulator injection and teardown.

## H106 SIM guide (0.1.8)

Supported Tiga/Zero models display an **插卡指引 / Insert SIM card** button after
loading. It opens the SDK's modal and plays opening the bottom cover, showing
the **芯片向上 / Chip side up** cue, sliding into the slot and closing the cover.
The compact player puts the active instruction, replay, pause and a thin
progress slider below the full-width model. Its surface follows the host's
background with matching text contrast. Escape or the close button
restores the original camera, controls and cover state. The modal reuses the
current canvas and verified model without another download or renderer. Model
materials, lighting, shadows, exposure, bloom and the host background are retained.

```ts
const viewer = createH106Viewer(container, {
  model: 'h106-tiga',
  simGuideButton: false, // A custom toolbar supplies the entry button.
})
await viewer.ready
if (viewer.hasSimGuide) viewer.openSimGuide()
viewer.closeSimGuide()
```

`hasSimGuide` is false before readiness or for an unreviewed explicit GLB;
`openSimGuide()` then returns false. `simGuideOpen` exposes the modal state.
The direction rig is bound to reviewed Tiga/Zero asset digests. Viewer teardown
removes the modal and guide geometry. Reduced-motion browsers start at a static
chip-side-up pose. Seating depth, hinge motion and physical SIM recognition are
not hardware acceptance. Open the guide from a user action to enable audio.

The rounded card is accompanied by four short spoken instructions, using the
Doubao TTS recordings for the selected language (Vivi 2.0 in Chinese and Allison 2.0 in English).
The speaker button mutes narration. Pause, seek and replay use the same 11.4-second
audio timeline; close/destroy stop playback. `sound: false` disables narration.
The SDK lazily loads the language's verified Ogg Opus recording from
`models/h106/sim-guide/manifest.json`; provider credentials stay in the offline
synthesis process. Failed/blocked audio leaves the visual guide usable.

## Play (0.1.9)

```ts
import { loadModelPlay, createModelsProvider } from '@gizclaw/models-player'
import '@gizclaw/models-player/style.css'

const { createModelPlay } = await loadModelPlay()
const play = createModelPlay(container, {
  model: 'h106-tiga',
  modelsProvider: createModelsProvider(),
})
await play.ready
// On unmount:
play.destroy()
```

The mounted **进入 Play** button opens a page-filling game view, installs the
selected firmware page and faces the model's screen. Press **B / Esc**, or touch the
model's physical power key, to run WASM and unlock audio. The existing D/F or J/K,
E/R or U/I, C/V or M/comma, Space and B/Esc bindings continue to drive the actual 3D keys. Arrows still
rotate the view. Play shows only exit and a compact menu; firmware and power
actions live in that menu, alongside a noninteractive keyboard legend. There
is no duplicate device-button toolbar. Normal exit releases input, waits for the
Web runtime's stop acknowledgement and then removes its page. Reinstall after
power-off to restart app_host's one-shot session.
Short taps retain a visible mechanical press/rebound even between render frames;
returning from fullscreen restores keyboard focus after native teardown.

ModelsProvider owns compatible firmware choices and available versions. The default `createModelsProvider()` reads `https://static-volc.gizclaw.com/models/play-trial/manifest.json`; Deploy owns that catalog. SDK 0.4.0 selects H106 Trial; the legacy `models/play/manifest.json` remains available for older SDKs. Pass `{url, versions}` for another public catalog or exact per-firmware version pins, or implement the `ModelsProvider` interface. After `play.ready`, `play.firmwares` supplies the provider's choices. `await listModelFirmwares(model, provider)` is also available. The SDK has no built-in product/firmware whitelist and rejects installation of identities absent from the provider snapshot.

The SDK downloads an integrity-bound `.web.tar` / `.web.tar.gz` from static-volc's
versioned firmware release path, validates/extracts the bounded flat app_host
archive, and creates a same-origin HTML Blob document using the embedding
document's own URL/Blob constructors. Its internal iframe navigates to that exact
owned URL, with verified Blob JS/WASM/data bindings and no firmware-byte patch.
Install downloads bytes; B/Esc starts WASM and audio. Firmware payloads stay
outside npm. The host needs cross-origin isolation for pthread SharedArrayBuffer
and a CSP allowing the reviewed inline script, `blob:` scripts/workers, WASM
compilation and **`frame-src blob:`** (plus `'self'` for HTTP entry adapters).
Host CSP/COOP/COEP remain in force; no extra network host or capture permission
is added. An explicit same-origin HTTP(S) `entryUrl` stays unchanged.

An actual WKWebView probe showed AudioWorklet Blob-module loading fail inside
`about:srcdoc` but succeed in HTTP and same-origin Blob HTML documents while
retaining cross-origin isolation. The Blob document avoids this document-origin
problem without hiding microphone errors or creating an AudioContext. All HTML
and asset URLs stay live until firmware shutdown is acknowledged; successful
shutdown, unstarted shutdown, forced destruction, failed load and abort detach
the frame and revoke them once. Real microphone capture remains a separate
acceptance boundary. Advanced `resolveFirmware` adapters remain constrained by
ModelsProvider admission.

Forge passes `embedded: true, presentation: 'inline'`: Play runs on its existing
model stage and keeps the same camera/zoom, canvas and tuning panel. It opens
no dialog and never invokes fullscreen. The host uses `state`, `install()` and
`exit()` for its own compact controls. The default fullscreen presentation
remains available to other consumers, including native WebView hosts.

Browser Play tries the Fullscreen API and retains a viewport fallback. For
LiteLink pass `fullscreenHost: { enter(model), exit() }` to expand the native
WebView and restore its layout/system UI through the app's bridge. Viewport
mode covers the WebView's page; the native app owns its physical screen bounds.
Call `enter()`/`start()` from actual click handlers. `state` and
`onStateChange` expose mode, phase, firmware, fullscreen kind and errors.

For firmware with the updated app_host environment hook, customize the default
dual-radio policy with an explicit `environment`:

```ts
const environment = {
  version: 1 as const,
  wifi: { enabled: true, connected: true, ssid: 'Browser Wi-Fi', rssi: -48 },
  modem: { enabled: true, simPresent: true, registered: true, rssi: -70 },
}
// createModelPlay(container, { ...options, environment })
// Switch scenarios on the same runtime:
play.setEnvironment(environment)
```

GizOS provides the fake Wi-Fi/modem PALs. The SDK validates and injects policy
before Start. Real browser Fetch/WebRTC still carry traffic; disabling all fake
data paths marks the runtime network unavailable. Omitted `environment` uses the
documented dual-radio preset; older firmware without the hook is rejected.

Local preview uses existing `h106-tiga.web.tar` and `h106-zero.web.tar`:

```sh
make models-player-play-prepare PLAY_TIGA_ARCHIVE=/absolute/tiga.web.tar PLAY_ZERO_ARCHIVE=/absolute/zero.web.tar
make dev-gizforge-models
# http://127.0.0.1:4187/console/?view=model-lab
make test-browser-models-player-play
```

Testing uses Forge's existing model page. `embedded: true` suppresses an extra
preview shell; `controller.viewer` exposes the same viewer for existing tuning
controls, and `viewerOptions` preserves its normal core/audio callbacks.
The loopback Forge preview serves its built console with a read-only session
fixture and verified local firmware. The production firmware route and normal
Forge rollout remain separate. Browser evidence is in `build/forge-model-lab`.
See the [owning guide](../../../../guides/models-player-sdk.md) for delivery and
native/fullscreen contracts.

## Normal shutdown (0.3.1)

`await play.shutdown()` / `await view.shutdown()` requests Stop and releases input
synchronously, then waits while retaining the firmware iframe and its ancestors.
Concurrent calls share one barrier. `view.shutdown()` does not call `onClose` or
remove its root; await it before the host route/document is removed. The footer
uses the existing busy spinner with “正在退出…” / “Closing…”, without adding a
public phase or claiming saved data.

The default Web adapter observes app_host's final
`H2_WEB_APP name=… result=PASS rc=0 fs=0 destroy=0` status, with the observer
installed before Stop. FAIL or the default five-second timeout rejects and forces
cleanup. An unstarted runtime needs no acknowledgement; a close during early
WASM loading may time out safely if its Stop export was not ready. No additional
WASM, AudioContext, media request or firmware patch is created.

Normal exit and install/reinstall await the barrier. The void `stop()`/`suspend()`
methods begin it; use `shutdown()` to await completion. Header Close invokes the
host callback once after the barrier settles, including failures. Web dialog
`close()` restores scroll/focus and cleans up even when it rejects, so a failed
stop cannot trap the user. Native hosts should report a failed acknowledgement
and force-close rather than claiming successful persistence.

`destroy()`/pagehide remain synchronous best-effort cleanup and cannot guarantee
pending preference writes. Custom `ModelFirmwareRuntime.shutdown` is optional;
without it the existing synchronous Stop behavior remains, with no new storage
guarantee. A custom barrier supplies its own completion bound. Product storage
and flush policy belong to the firmware: producer shutdown acknowledgement is
not an independent receipt for every preference write. The SDK never reads or
fabricates tutorial state.

## Read-only Play audio status (0.3.1)

`play.audio` exposes a fresh frozen snapshot of the installed firmware's audio:
`state` is `not-started`, `running`, `suspended`, `interrupted`, `closed` or
`unavailable`; optional `firmwareVolumePercent` is the reported Speaker PAL
setting (0–100), not phone system volume. Missing/custom runtimes can return no
snapshot. No child window, context, stream or gain node is exposed.

The shared Play View keeps a small audio information button visible in Model and
Screen. Running with firmware volume zero shows **Firmware muted**; a later
positive volume restores the engine-state label. Suspension/interruption takes
priority. Details retain the actual engine state and firmware volume and explain
that a running engine does not guarantee audibility. Web pages cannot reliably
read the phone's silent switch or system volume; users can check system volume
and output devices when no sound is heard. Opening details never resumes audio,
creates a context or requests microphone permission.

Phone badge slots stay outside the model stage and keys; tablet/desktop reuse
the footer status row. Both views retain the same firmware/audio instance.
See the owning guide for field provenance, fallback and qualification boundaries.

## Screen-only host views (0.2.0)

`play.display` returns a fresh `ModelPlayDisplay` snapshot with the borrowed live
firmware `canvas` and its effective `displayBrightnessPercent` (0–100). Read it
each host frame. The framebuffer is unscaled: the host applies backlight and
owns the layout/view switch. Copy the source canvas with `drawImage`; do not
resize, reparent or dispose it. No iframe access is needed.

```ts
// `play` is the existing ModelPlay controller; `screen` belongs to the host.
const context = screen.getContext('2d')!
play.setModelRenderingEnabled(false)
let request = 0
function drawScreen() {
  context.globalAlpha = 1
  context.fillStyle = '#000'
  context.fillRect(0, 0, screen.width, screen.height)
  const display = play.display
  if (display) {
    context.globalAlpha = display.displayBrightnessPercent / 100
    context.drawImage(display.canvas, 0, 0, screen.width, screen.height)
    context.globalAlpha = 1
  }
  request = requestAnimationFrame(drawScreen)
}
drawScreen()
// When returning to the visible model:
cancelAnimationFrame(request)
play.setModelRenderingEnabled(true)
```

The display is null in preview, before/during installation, after failed
replacement, stop, exit or destroy. Installed firmware exposes a canvas with
zero brightness before Start. Reinstalling changes the canvas identity, so
discard old snapshots and read the getter again.

`play.modelRenderingEnabled` defaults to true. Its setter also works before
`ready`; the selection persists across installation and mode changes.
Suspension cancels only the model frame loop, retaining firmware execution,
audio, input listeners and the existing scene/camera/zoom. Resuming applies
deferred sizing and starts with a fresh elapsed-time anchor. It is independent
of `appearance.pauseCore()` and never powers the firmware off. Both renderer
families also expose `viewer.renderingEnabled` / `setRenderingEnabled()`.
Destroy is terminal and reports rendering disabled.

Place a focusable host screen canvas inside the player container to retain the
existing keyboard shortcuts. A screen hosted elsewhere can forward events
through the existing public H106 `viewer.buttons` interface. Normal blur,
exit/reinstall and teardown still release held input.

This API retains the host's explicit radio environment. Forge already supplies
simulated Wi-Fi plus cellular; it does not choose the firmware's backend
environment. The webpage owns the third view and any optical/crop treatment.
`make test-browser-models-player-screen` checks the public API with real models
and an independently animated app_host fixture. The packed provider consumer
also checks continued real WASM execution during suspension.

## H106 energy core (0.1.4)

H106 opens with the **large oval optical cover facing the user**, initially blue
at full energy. Each completed tap switches exactly once between steady blue
(`full`) and blinking red (`low`), with a short press/rebound animation of the
cover, inner facets and backing together, and an appearance-specific recording.
The Tiga ready sound is the first `迪迦叫声.mp3` attachment in
[H106界面文案以及提示音](https://qibuqibu.feishu.cn/docx/A4XvdSm42oDU3ixogzGcHvZJnse).
Tiga and Zero use their respective timer attachments for low energy. Zero's
ready sound uses the confirmed short ha call from its sound discovery.
The clips are Ogg Opus and load from the
shared `https://static-volc.gizclaw.com/models/h106/sounds/manifest.json` inventory;
`model_sounds` selects only the requested appearance's two recordings.
Appearance-specific sound selection was introduced in version 0.1.7.
Published 0.1.6 and earlier use the retained legacy pair in that inventory.
The red alarm loops until stopped or replaced; switching to blue stops it
immediately and plays the ready call once.
Leading/trailing noise and silence are removed; timer clips retain four complete
cycles with short boundary fades. The recordings preserve pitch and tempo.
Tiga flashes about every 0.526 seconds, Zero about every 0.667 seconds.
Red light turns fully on for
the high notes and completely off for the low notes, using the AudioContext
speaker output clock and predicting the next display frame. Tempo is fixed;
there is no speed setting. Muted rendering retains each appearance's recorded rhythm,
and `pauseCore()` pauses both the light clock and sound.
Dragging, canceled pointers and multitouch
do not toggle energy. The small key on the screen side remains the power button.
Its pale silver cap and bevel retain their CAD metallic factor independently
of the shell's metalness slider; the separate dark bezel stays visible.
The core glows through its emissive facets and rim with bloom; it has no
unshadowed interior point light that could illuminate the screen-side buttons.
Space while the canvas is focused and the labeled core button provide keyboard
access. Existing Record press/release events remain available to applications.
Tiga and Zero share the keyboard layout: **D/F or J/K** left/right, **E/R or U/I** Back/OK,
**C/V or M/,** volume down/up, **Space** core and **B/Esc** Power. Bindings use physical
key codes, including when letter case changes while a key is held.
Hold the arrow keys to rotate the view; release to stop. Click the model first
to focus it. Blur, hidden tabs and teardown also release held rotation keys.

```ts
const viewer = createH106Viewer(container, {
  model: 'h106-tiga',
  initialEnergyState: 'full', // Default; alternatively 'low'.
  sound: true,               // Default; false skips audio downloads and playback.
  onEnergyChange: state => console.log(state),
})
await viewer.ready
console.log(viewer.energyState)
viewer.setEnergyState('low') // Silent programmatic change; callback fires once.
```

Sound-enabled H106 loading starts parallel prefetch of both recordings, verifying
the manifest and each OGG's size, MIME and SHA-256. Preloading creates no
AudioContext and never plays sound. Clicks share any in-flight download and use
the cached bytes; each clip is decoded once on demand from a copy of those bytes.
`viewer.preloadSounds()` lets a host explicitly await the cache. A failed preload
does not block the model, and playback can retry only the failed recording.
Switching stops the
previous voice, including a recording still loading. There is no synthesized
fallback. The npm archive contains no MP3/OGG payloads or third-party runtime URLs.
AudioContext is created only on user activation. Blocked audio does not prevent the
visual interaction. Destroy stops all voices, closes the audio context and
releases the pointer/keyboard and GPU resources. The optics use existing GLB
triangles bound to their asset digests; they are a realtime appearance treatment.
Unknown explicit GLBs still render without the digest-specific optical rig.

`initialView: 'core'` is the default; `'screen'` faces the display, while the
existing `'angle'` and `'back'` choices remain available. Reset restores the
chosen view without changing energy. Review adapters default to noninteractive
cores; pass `interactiveCore: true` to enable interaction in a tuning view.
These APIs are available starting with 0.1.4; retained 0.1.3 lacks these controls.

Use the sound-only API without loading Three.js or a 3D model:

```ts
import { createH106CoreSounds } from '@gizclaw/models-player'

const sounds = createH106CoreSounds({ model: 'h106-zero' }) // Defaults to Tiga; inert until preload/play.
await sounds.preload()               // Cache both clips; no AudioContext or sound.
// Call from your UI click/tap handlers:
await sounds.playLowEnergy()         // Red timer alarm, looping until stopped.
await sounds.playFullEnergy()        // Ready call, once; stops the prior voice.
sounds.stop()
sounds.destroy()
```

An older discovery without `model_sounds` still resolves the legacy pair. An
invalid or missing selected appearance in a newer inventory fails verification;
it cannot silently select the other appearance's sound. Each recording's
SHA-256 and decoded duration bind its measured light timing.
Silent/stopped rendering follows the resolved low recording's digest, so older
discovery keeps its legacy rhythm even when audio cannot be downloaded. A
sound-disabled viewer skips discovery and uses the appearance's default rhythm.

Mounted viewers expose `preloadSounds()`, `playLowEnergySound()`, `playFullEnergySound()` and
`stopSound()` for the same playback without changing visual energy state.
`sound: false` also mutes these explicit viewer methods. `setEnergyState()`
is silent and stops any previous voice. Playback resolves `false` when disposed,
superseded, muted, blocked or unable to load/verify a recording. Preload resolves
`false` when destroyed, muted or either recording fails; it never starts playback.

```ts
const { createThirdPartyHandheldViewer } = await loadModelPlayer('pi-tin')
const viewer = createThirdPartyHandheldViewer(container, {
  device: 'pi-tin',
  onButton: ({ button, pressed }) => { /* Application input */ },
})
await viewer.ready
viewer.setLidOpen(false)
viewer.destroy()
```

Pi Tin selects only `models/pi-tin/manifest.json` and its verified GLB.
Its exact-digest interaction rig supports lid opening, WASD D-pad, I/J/K/L
for the right cluster (I X, J Y, K B, L A), F Select and H Start.
Arrow keys continuously rotate the view while held.
Input releases on close, lost focus, pointer cancellation and destroy.
The motions are presentation choices, not qualified mechanical constraints.
Pi Tin is an independent third-party device; this package grants no H106
firmware compatibility or manufacturing identity.

`@gizclaw/models-player/handhelds` provides lightweight FunKey S and Pi Tin
source references. Handheld is the generic device category, not a model name.
FunKey S has no admitted public GLB. Its generic renderer requires a
caller-owned licensed explicit verified GLB. The product renderer modules are
also exposed at `/h106` and `/third-party`; use dynamic imports for lazy loading.

## Shared material and lighting controls

Every viewer supplies `appearance` after `ready`, including explicit third-party
GLBs. Forge's model laboratory and board previews use this same API:

```ts
await viewer.ready
viewer.appearance?.setFinish('satin')
viewer.appearance?.setLighting('dark')
viewer.appearance?.configure({ roughness: 0.4, exposure: 0.55 })
viewer.appearance?.setAutoRotate(true)
viewer.appearance?.compareOriginal(true)
viewer.appearance?.reset()
const settings = viewer.appearance?.getSettings()
```

Settings are copied and validated. Original alpha/textures are preserved;
destroy releases all cloned materials and postprocessing resources. H106 optical
controls use `appearance.hasEnergyCore`; other models share material/light/view
controls. Pi Tin hosts can use `onLidChange(open)` to track lid interaction.

The prepared Tiga defaults are satin/studio with roughness 0.3, metalness 0.6,
clearcoat 0, grain 0.11, key 0.9, fill 2.24, rim 0, exposure 0.31, env 0, bloom
0.49, energy 8 and transmission 0.86. Reset restores that look. Other models
retain their own SDK defaults.

Selected views fit both canvas dimensions, including narrow embedded hosts;
resizing preserves relative user zoom. Bloom leaves empty canvas pixels
transparent and retains the optical halo without an opaque background.

### Relative view rotation in 0.1.6

After `ready`, all viewers support incremental horizontal orbit rotation:

```ts
viewer.appearance?.rotateBy(deltaScroll * sensitivity)
```

The increment is in radians, relative to the current visible camera pose around
the model's up axis. Positive values increase camera azimuth; negative values
decrease it. The target, orbit distance and zoom are preserved, and camera angle
limits apply. Each nonzero increment clears residual drag/pan damping so the
requested rotation is exact. Auto-rotation retains its current setting and
continues on later frames; hosts can use `setAutoRotate(false)` for scroll-only
rotation. Zero is a no-op; non-finite or non-numeric increments throw `RangeError`
before changing the view. Calls after viewer destruction have no effect.
The increment does not change or become part of exported appearance settings.
Version 0.1.5 has no `rotateBy()` method; this API requires 0.1.6 or later.

## Assets and release

Source and model declarations share `gizclaw/catalogs/models`: `player/`,
`h106/tiga/`, `h106/zero/` and `pi-tin/`. External asset paths mirror planned
CDN paths below `models/`, including immutable model-version directories.
The package verifies canonical URLs, MIME, bounded sizes and SHA-256 before
rendering. It bundles no GLB, STEP, firmware, credentials or Three.js source.
`SOURCE.json` retains the renderer's original upstream provenance and hashes.
Pi Tin's conversion source/license/attribution accompany its external model.

`make models-player-package` prepares a local archive, provenance index and
checksums in `build/models-player/<version>`. The manual
`release-models-player.yml` workflow and existing TOS npm importer require
separate publication authorization. Local dirty-source indexes cannot be
imported. Model publication and application rollout are separate operations.
See `guides/models-player-sdk.md` in the source repository for the full contract.

`H106Simulator.outputs` carries `displayBrightnessPercent` and the optical average of the firmware chest strip RGB. Play reads `Module.h2WebOutputs` from the Web PAL; closed/stopped sessions are black. Both H106 displays lift dim framebuffer midtones with a highlight-preserving response before applying the firmware backlight. Black stays black, white and saturated primaries retain their endpoints, and native dimming/sleep still apply. The real 3D display is composited after studio tone mapping with body depth occlusion, so changing studio exposure does not dim firmware text. Showcase energy intensity, demo sound and pulse controls do not override runtime LEDs. Leaving Play restores the showcase.

Firmware discovery starts alongside preview rendering and has a ten-second bound. Unavailable or malformed metadata disables Play; the model and its preview/SIM-guide controls remain usable. Reload to retry discovery.
